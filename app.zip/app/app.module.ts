import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

import { PaymentModule } from './payment/payment.module';
import { AppRouterModule } from './app.routes';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { IcpService } from './icp.service';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

import { BannerComponent } from './banner/banner.component';
import { MenuComponent } from './menu/menu.component';
import { BodyComponent } from './body/body.component';
import { FooterComponent } from './footer/footer.component';
import { GreetPipe } from './greet.pipe';
import { CalculatorComponent } from './calculator/calculator.component';
import { CalService } from './cal.service';
import { MyProductsComponent } from './my-products/my-products.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { ZenDirective } from './zen.directive';
import { ClimateComponent } from './climate/climate.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { TformComponent } from './tform/tform.component';
import { RformComponent } from './rform/rform.component';
import { RgerrorsComponent } from './rgerrors/rgerrors.component';
import { ValidatedirComponent } from './validatedir/validatedir.component';
import { ValidatdirDirective } from './validatdir.directive';

import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { ServerComponent } from './server/server.component';
import { BasicComponent } from './basic/basic.component';
import { HttpclientComponent } from './httpclient/httpclient.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    BannerComponent,
    MenuComponent,
    BodyComponent,
    FooterComponent,
    GreetPipe,
    CalculatorComponent,
    MyProductsComponent,
    PagenotfoundComponent,
    ZenDirective,
    ClimateComponent,
    FeedbackComponent,
    TformComponent,
    RformComponent,
    RgerrorsComponent,
    ValidatedirComponent,
    ValidatdirDirective,
    ServerComponent,
    BasicComponent,
    HttpclientComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    PaymentModule,
    AppRouterModule,
    ReactiveFormsModule,
    HttpModule,
    HttpClientModule
  ],
  providers: [CalService,IcpService,{
      provide:HTTP_INTERCEPTORS,
      useClass: IcpService,
      multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
