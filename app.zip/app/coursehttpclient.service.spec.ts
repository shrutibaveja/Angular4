import { TestBed, inject } from '@angular/core/testing';

import { CoursehttpclientService } from './coursehttpclient.service';

describe('CoursehttpclientService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CoursehttpclientService]
    });
  });

  it('should be created', inject([CoursehttpclientService], (service: CoursehttpclientService) => {
    expect(service).toBeTruthy();
  }));
});
