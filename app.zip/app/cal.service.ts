import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CalService {

  constructor() {
   }
   perimeterRect(l,b){
  		var perimeter = 2*(l+b);
  		return perimeter;

   }
  	areaRect(l,b){
  		var area = l*b;
  		return area;
  	}
}
