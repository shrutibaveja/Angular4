import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CoursehttpclientService {

  constructor(private http: HttpClient) { }

  postUrl = "/ngbootcamp/api/testapi.php";
  getCourses(): Observable<any>{
  	const req = new HttpRequest('GET',this.postUrl,{
  		reportProgress: true
  	});
  	console.log('came in');
  	return this.http.request(req);
  }

}
