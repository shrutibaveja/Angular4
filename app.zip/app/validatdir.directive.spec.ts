import { ValidatdirDirective } from './validatdir.directive';

describe('ValidatdirDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidatdirDirective();
    expect(directive).toBeTruthy();
  });
});
