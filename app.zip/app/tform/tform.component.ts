import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tform',
  templateUrl: './tform.component.html',
  styleUrls: ['./tform.component.css']
})
export class TformComponent implements OnInit {
	boundName:string = "Abc Aaa";
  constructor() { }

  ngOnInit() {
  }
  submitForm(formOb){
  	console.log(formOb.value);
  }
  showNameValue(){
  	alert(this.boundName);
  }

}
