import { Component, OnInit, Input } from '@angular/core';
import { AbstractControlDirective, AbstractControl } from '@angular/forms';

@Component({
  selector: 'app-rgerrors',
  templateUrl: './rgerrors.component.html',
  styleUrls: ['./rgerrors.component.css']
})
export class RgerrorsComponent implements OnInit {

private static readonly errorMessages = {
	'required': () => 'required field is needed',
	'minlength': (params) => 'The min no. of characters is' + params.requiredLength,
	'maxlength': (params) => 'The max allowed no. of characters is' + params.requiredLength,
	'pattern': (params) => 'The required pattern is' + params.requiredPattern,
	'age' : function (params) {return "text added" + params.message;},
	'validEmail' : (params) => params.message,
	'name' : (params) => params.message
};

@Input()
private control: AbstractControlDirective | AbstractControl;

showErrors():boolean{
	console.log(this.control);
	return this.control && this.control.errors && 
	(this.control.dirty || this.control.touched);
}

// this returns all messages.
errors(): string[]{
	console.log(this.control);
	return Object.keys(this.control.errors)
	.map(field => { console.log(field); return this.getMessage(field,this.control.errors[field])})
}

private getMessage(type:string,params:any){
	return RgerrorsComponent.errorMessages[type](params);
}
  constructor() { }

  ngOnInit() {
  }

}
