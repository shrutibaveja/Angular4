import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PayuiComponent } from './payui.component';

describe('PayuiComponent', () => {
  let component: PayuiComponent;
  let fixture: ComponentFixture<PayuiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PayuiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PayuiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
