import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payui',
  templateUrl: './payui.component.html',
  styleUrls: ['./payui.component.css']
})
export class PayuiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
