import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PayuiComponent } from './payui/payui.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [PayuiComponent],
  exports: [PayuiComponent]
})
export class PaymentModule { }
