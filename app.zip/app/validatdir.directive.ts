
import { Directive, Component, OnInit } from '@angular/core';
import { NG_VALIDATORS, FormControl, Validator, ValidationErrors } from '@angular/forms';

@Directive({
  /*selector: '[appValidatdir]'*/
  selector: '[name-validate]',
	providers: [{provide: NG_VALIDATORS, useExisting:ValidatdirDirective, multi:true }]
})
export class ValidatdirDirective {

validate(c: FormControl): ValidationErrors{
	/*alert("Inside Validate")*/
		const name = String(c.value);
		console.log(c);
		console.log("Validate NAme:  ", name)
		const isValid = name.length >= 3 && name.length <=20 && name!='Ghost';
		const message = {
			'name':{
				'message':'Length = more than 3 and less than 20, No Ghost allowed'
			}
		};
		return isValid ? null: message;
	}

  constructor() { /*alert("Inside Constructor");*/ }

}
