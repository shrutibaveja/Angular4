import { ZenDirective } from './zen.directive';

describe('ZenDirective', () => {
  it('should create an instance', () => {
    const directive = new ZenDirective();
    expect(directive).toBeTruthy();
  });
});
