import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.css']
})
export class BodyComponent implements OnInit {
	title = 'Angular Course';
	coursePrice = 120;
	timeStamp;
	name = "Shruti";
  constructor() {

  	var dateObj = new Date();
  	this.timeStamp = dateObj.getTime();
   }

  ngOnInit() {
  }

}
