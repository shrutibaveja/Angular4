import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, NgForm, AbstractControl } from '@angular/forms';
import { CustomValidators } from '../classes/customvalidators';

/*function AgeValidator(a:AbstractControl):{[key:string]:boolean}|null{
	console.log('ran validator'+a.value);
	if((a.value<18||a.value>139)){
		return{'confused':true};
	}
}*/

@Component({
  selector: 'app-rform',
  templateUrl: './rform.component.html',
  styleUrls: ['./rform.component.css']
})

export class RformComponent implements OnInit {
  reactiveForm: FormGroup;

  constructor() {
  this.reactiveForm = new FormGroup({
  	'name': new FormControl(''),
  	'age': new FormControl('',[Validators.required]),
  	'description': new FormControl()
  })  
}

  ngOnInit() {
  }
  submitForm(formData:NgForm){
  	console.log(formData.value);
  }

}
