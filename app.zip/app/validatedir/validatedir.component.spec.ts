import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ValidatedirComponent } from './validatedir.component';

describe('ValidatedirComponent', () => {
  let component: ValidatedirComponent;
  let fixture: ComponentFixture<ValidatedirComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ValidatedirComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ValidatedirComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
