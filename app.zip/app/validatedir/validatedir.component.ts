import { Directive, Component, OnInit } from '@angular/core';
import { ValidatdirDirective } from '../validatdir.directive';
import { CustomValidators } from '../classes/customvalidators';

@Component({
  selector: 'app-validatedir',
  templateUrl: './validatedir.component.html',
  styleUrls: ['./validatedir.component.css']
})
export class ValidatedirComponent implements OnInit {



  constructor() { }

  ngOnInit() {
  }

}
