import { Routes,RouterModule } from '@angular/router';
import { CalculatorComponent } from './calculator/calculator.component';
import { BodyComponent } from './body/body.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { MyProductsComponent } from './my-products/my-products.component';

const routes:Routes = [

{
	path:'',
	component:BodyComponent
},
{
	path:'something',
	component:CalculatorComponent
},
{
	path:'products/:id',
	component:MyProductsComponent
},
{
	path:'**',
	component:PagenotfoundComponent
}
	
]

export const AppRouterModule = RouterModule.forRoot(routes,{enableTracing:false})