import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
//import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Subscription } from 'rxjs';

import { Headers, RequestOptions } from '@angular/http';

@Injectable({
  providedIn: 'root'
})

export class CourseserviceService {
postUrl = "/ngbootcamp/api/testapi.php";
getCourses(): Observable<any>{

	return this.http.get(this.postUrl).pipe(map((res:Response) => res.json()));
	
}
 constructor(private http:Http) { }
}
