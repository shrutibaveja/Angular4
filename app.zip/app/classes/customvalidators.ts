import { FormArray, FormControl, FormGroup, ValidationErrors} from '@angular/forms';

class CustomValidators {
	public static validEmail(c: FormControl): ValidationErrors{
		const email = c.value;
		console.log(c);
		var reg = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/
		var isValid = true;
		const message = {
			'validEmail':{
				'message':'Should be valid'
			}
		};
		if(reg.test(email)){
			isValid = true;
		}
		else{
			isValid = false;
		}
		return isValid?null:message;
	}
	
	public static ageValidate(c: FormControl): ValidationErrors{
		const num = Number(c.value);
		const isValid = !isNaN(num) && num >=18 && num <= 85;
		const message = {
			'age':{
				'message':'age invalid'
			}
		};
		return isValid?null:message;
	}
}

export {CustomValidators};
