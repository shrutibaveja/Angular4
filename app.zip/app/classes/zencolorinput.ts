class ZenColorInput{
	color:string;
	borderColor:string;
	padding:string;
}

export {ZenColorInput};