import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-my-products',
  templateUrl: './my-products.component.html',
  styleUrls: ['./my-products.component.css']
})
export class MyProductsComponent implements OnInit {
  pid:number;
  constructor(private routeVars: ActivatedRoute) { }

  ngOnInit() {
  	this.pid = this.routeVars.snapshot.params['id'];
  }

}
