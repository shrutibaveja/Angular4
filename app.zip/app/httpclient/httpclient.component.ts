import { Component, OnInit } from '@angular/core';
import { HttpRequest, HttpEvent, HttpEventType } from '@angular/common/http';
import { CoursehttpclientService } from '../coursehttpclient.service';


@Component({
  selector: 'app-httpclient',
  templateUrl: './httpclient.component.html',
  styleUrls: ['./httpclient.component.css']
})
export class HttpclientComponent implements OnInit {
  data:any;
  constructor(private ob:CoursehttpclientService ) { this.getCourse(); }

  ngOnInit() {
  }

  getCourse(){
  	this.ob.getCourses().subscribe((event:HttpEvent<any>) =>{
		switch(event.type){
			case HttpEventType.Sent:
			console.log("Request Sent!");
			break;

			case HttpEventType.ResponseHeader:
			console.log("Response Header Recieved!");
			break;

			case HttpEventType.DownloadProgress:
			console.log(event.loaded);
			const pvar = Math.round(event.loaded);
			console.log(`in progress! ${pvar} bytes loaded`);
			break;

			case HttpEventType.Response:
			console.log("Done!", event.body);
			this.data = event.body;
			break;
		}
  	})
  }

}
