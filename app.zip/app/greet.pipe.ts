import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'greet'
})
export class GreetPipe implements PipeTransform {

  transform(value: any, args1?: any, args2?: any): any {
  	if(args1 == "morning"){
  		var newVal = "Hello "+value+",  Good Morning. City: "+args2;
  	}
	if(args2 == "evening"){
  		var newVal = "Hello "+value+",  Good Evening. City: "+args2;
  	}
  	
  	return newVal;
    
  }

}
