import { Component, OnInit } from '@angular/core';
import { CourseserviceService } from '../courseservice.service'; 

@Component({
  selector: 'app-server',
  templateUrl: './server.component.html',
  styleUrls: ['./server.component.css']
})
export class ServerComponent implements OnInit {
  course;
  constructor(private ob:CourseserviceService) { }

  ngOnInit() {
  }

  getCourseInComponent(){
  	this.ob.getCourses()
  	.subscribe(res=>{console.log(res); this.course = res;});
  }

}
