import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-climate',
  templateUrl: './climate.component.html',
  styleUrls: ['./climate.component.css']
})
export class ClimateComponent implements OnInit {
  visitors:number;
  @Input()
  temp:number;
  @Output() notifyparent:EventEmitter<number> = new EventEmitter<number>();
  emitEvent(){
  	console.log('Event Emitted');
  	this.notifyparent.emit(this.visitors);
  }
  constructor() { }

  ngOnInit() {
  }

}
