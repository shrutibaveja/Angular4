import { Component } from '@angular/core';
//import { ZenColorInput } from './classes/zencolorinput';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular class!';
  student:any;
  zci:any;
  colorVal = "cyan";
  htmlVal = "<b>Does it work?</b>";

  childvisitors:number;

  getChildData(data){
  	alert(data);
  	this.childvisitors = data;
  }
  
  constructor(){
  	
  	setTimeout(() =>{
  		this.student = {
  			firstName:'Sumit',
  			age:21
  		}
  	},4000);

  }
  ngOnInit(){
  	this.zci = {color:"mazenta", borderColor:"pink",padding:"18px"};
  }
}
