import { TestBed, inject } from '@angular/core/testing';

import { IcpService } from './icp.service';

describe('IcpService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [IcpService]
    });
  });

  it('should be created', inject([IcpService], (service: IcpService) => {
    expect(service).toBeTruthy();
  }));
});
