import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
   providedIn: 'root'
})
export class IcpService implements HttpInterceptor {
	intercept (req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>{
		console.log("We have intercepted the request");
		console.log(req);
		const authReq = req.clone({
			headers: req.headers.set('Authorization','ZenToken12')
		});
		return next.handle(authReq);
	}

  constructor() { }
}
