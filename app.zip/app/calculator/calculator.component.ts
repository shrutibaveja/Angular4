import { Component, OnInit } from '@angular/core';
import { CalService } from '../cal.service';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.css']
  /*providers:[CalService]*/
})
export class CalculatorComponent implements OnInit {

	public length:number;
	public breath:number;
	public perimeter:number;
	public area:number;

  constructor(private calObj:CalService) {
   }

  ngOnInit() {
  }
  findPerimeter(){
  	this.perimeter = this.calObj.perimeterRect(this.length,this.breath);
  }
  findArea(){
  	this.area = this.calObj.areaRect(this.length,this.breath);
  }

}
