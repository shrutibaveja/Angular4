import { Component, OnInit, Renderer2, ViewChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {

  @ViewChild('boxnew') boxnew: ElementRef;
  /*isBoxAdded:boolean = false;
  gc:boolean = true;
  ge:boolean = true;*/

  selectedId:number;
  k:number=0;
  isBoxAdded:boolean = false;
  
  taste = [{"id":1,"value":"Bad","show":true},{"id":2,"value":"Average","show":true},{"id":3,"value":"Good","show":true},{"id":4,"value":"Very Good","show":true}];

  constructor(private rendererOb: Renderer2) {

    /*for(this.k; this.k<this.taste.length; this.k++){
      this.taste[this.k].show = true;
    }*/

  }

  ngOnInit() {
  }

  /*addBox(){
  	if(!this.isBoxAdded){
  		const inputBox = this.rendererOb.createElement('input');
  		this.rendererOb.appendChild(this.boxnew.nativeElement, inputBox);
  		this.isBoxAdded = true;

  	}
  }

  toggleGc(){
  	this.gc = !this.gc;
  }
  toggleGe(){
  	this.ge = !this.ge;
  }*/

  addTextbox(){
    if(!this.isBoxAdded){
      const inputBox = this.rendererOb.createElement('textarea');
      this.rendererOb.appendChild(this.boxnew.nativeElement, inputBox);
      this.rendererOb.setStyle(this.boxnew.nativeElement, 'float', 'left');
      this.rendererOb.setStyle(this.boxnew.nativeElement, 'display', 'inline');
      this.rendererOb.setStyle(this.boxnew.nativeElement, 'padding', '2px 10px');
      this.rendererOb.setStyle(this.boxnew.nativeElement, 'border', '1px solid purple');
      this.isBoxAdded = true;

    }
  }

  toggleIcon(btnId){
    this.selectedId = btnId;
    console.info("this.selectedId",this.selectedId);
    this.taste[this.selectedId-1].show = !this.taste[this.selectedId-1].show;
  }

}
