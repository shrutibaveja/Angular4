import { Directive, Input, HostListener } from '@angular/core';
import { Renderer, ElementRef } from '@angular/core';
import { ZenColorInput } from './classes/zencolorinput';

export enum KEY_CODE{
  RIGHT_ARROW = 39,
  LEFT_ARROW = 37,
  UP_ARROW = 38
}

@Directive({
  selector: '[appZen]'
})
export class ZenDirective {
@Input() appZen:any;
@Input() newvar:ZenColorInput;
className: string;

constructor( public renderer:Renderer, public el:ElementRef) { 
    this.className = 'directive-css';
}

@HostListener('window:keyup', ['$event'])
keyEvent(event:KeyboardEvent){
  console.log(event.keyCode);

  if(event.keyCode === KEY_CODE.RIGHT_ARROW){
    this.renderer.setElementStyle(this.el.nativeElement, 'color', "Blue");
    this.renderer.setElementStyle(this.el.nativeElement, 'border', '4px solid Pink');
    
  }
  if(event.keyCode === KEY_CODE.LEFT_ARROW){
    this.renderer.setElementStyle(this.el.nativeElement, 'color', "Green");
    this.renderer.setElementStyle(this.el.nativeElement, 'border', '4px solid Purple');
    
  }
  if(event.keyCode === KEY_CODE.UP_ARROW){
    this.renderer.setElementStyle(this.el.nativeElement, 'color', "Mazenta");
    this.renderer.setElementStyle(this.el.nativeElement, 'border', '4px solid Yellow');
    
  }
  if(event.keyCode === 82){
    this.restoreEl();
    this.renderer.setElementClass(this.el.nativeElement, this.className, true);
  }
}
restoreEl(){
  this.renderer.setElementStyle(this.el.nativeElement, "border", "");
  this.renderer.setElementStyle(this.el.nativeElement, "color", "");
  this.renderer.setElementClass(this.el.nativeElement, null, true);
}

  
  ngOnInit(){
    /*this.appZen = JSON.parse(this.appZen);*/
    console.log("this.newvar--",this.newvar);
  	
  	this.renderer.setElementStyle(this.el.nativeElement, 'color', this.newvar.color);
  	this.renderer.setElementStyle(this.el.nativeElement, 'border', '4px solid '+this.newvar.borderColor);
  	this.renderer.setElementStyle(this.el.nativeElement, 'padding', this.newvar.padding);
    this.renderer.setElementStyle(this.el.nativeElement, 'font-weight', 'bold');
  }

}
